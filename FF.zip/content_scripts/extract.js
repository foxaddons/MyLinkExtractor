/*
 *  Link Gopher
 *  Copyright (C) 2008, 2009 Andrew Ziem
 *  http://sites.google.com/site/linkgopher/
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

function dedupe(a) {
    var a = a.sort();
    var a2 = new Array();
    a2.push(a[0]);
    for (i = 1; i < a.length; i++) {
        if (a[i] != a[i - 1]) {
            a2.push(a[i]);
        }
    }
    return a2;
}

function scrollToBottom()
{
    var height = document.body.scrollHeight;
    window.scroll(0 , height);
}

function scrollToTop() 
{
  window.scrollTo(0, 0);
}


function GetCurrentTabUrl() 
{
	var tab;

  browser.tabs.query({currentWindow: true, active: true}).then((tabs) => {
		tab = tabs[0]; // Safe to assume there will only be one result
	});

	return tab;
}



function SortKeyValueArray(db)
{
    var k2 = Object.keys(db).sort();
	
    if (k2.length <= 0)
	   return db;


    var narr = {};

    for (var i = 0; i < k2.length; i++)
    	   narr[k2[i]] = db[k2[i]];

    return narr;
}

function UpdatePageTitle()
{
	alert("page title");

	var y = document.getElementById("idpagetitle");

     y.innerHTML = document.title.trim();
}

function extractLinksMain(searchstring) 
{

    // extract the links

    var links = new Array();

    var chkarr = new Array(); // for same urls

    var titlechk = new Array(); // for same titles

    var tnum = 1;


    const pattern = searchstring ? new RegExp(searchstring, "gi") : null;

    //console.log(searchstring + "  =  " + pattern);

    //console.log("Links =  " + document.links.length);

 


    var TitleLinks = {};


    for (i = 0; i < document.links.length; i++) 
    {
	if (document.links[i].text)
	   {
		if (document.links[i].text.match(pattern)) 
           {

 // console.log(document.links[i].text + "  =  " + document.links[i].toString());


		 	// links.push(document.links[i].toString());
				
                if (!chkarr.includes(document.links[i].toString()))
			{
				
				if (titlechk.includes(document.links[i].text))
			 {
				var titlelocal = document.links[i].text + " - " + tnum;
				TitleLinks[titlelocal] = document.links[i].toString();
			  
                     titlechk.push(titlelocal);

                     tnum += 1;
			 }
			 else
			 {
				TitleLinks[document.links[i].text] = document.links[i].toString();
			  
                     titlechk.push(document.links[i].text);
			 }

                 chkarr.push(document.links[i].toString());
		
			}

		 }
         }
    }



    for (i = 0; i < document.links.length; i++) 
    {
        var thisLink = document.links[i].toString();

	   if (!chkarr.includes(document.links[i].toString()))
	   {
        	if (thisLink.match(pattern)) 
           { 	links.push(document.links[i].toString());   }
        }
    }


    // find embedded links
    var embedded_links = new Array();
    for (i = 0; i < links.length; i++) {
        var link = links[i];
        link = link.replace(/%3[Aa]/g, ":");
        link = link.replace(/%2[fF]/g, "\/");
        var re = /.(https?:\/\/.*)/g;
        var a = link.match(re);
        if (a !== null && a.length > 0) {
            embedded_links.push(a[0].substring(1));
        }
    }

    var links = links.concat(embedded_links);

    var links = dedupe(links);

    //var TitleLinks = SortKeyValueArray(TitleLinks);


    
    var heading = document.createElement("a");

    heading.setAttribute("href", "javascript:window.scrollTo(0, 0);");

    //heading.setAttribute("onclick", "scrollToTop();");
	
    heading.setAttribute("id", "exlu");
  
    heading.style.fontSize = "25px";
    heading.style.color = "Blue";


	
    heading.appendChild(document.createTextNode("Extracted Links"));
	
    document.body.appendChild(heading);

   
/*

    for (var key of Object.keys(TitleLinks))
    {
	   var linkElement = document.createElement("a");
	   var lineBreak = document.createElement("br");

        linkElement.setAttribute("href", TitleLinks[key]);
		
        linkElement.setAttribute("title", TitleLinks[key]);


        linkElement.appendChild(document.createTextNode(key + "   =>   " + TitleLinks[key]));
				
	   document.body.appendChild(linkElement);
	   document.body.appendChild(lineBreak);

    }

*/



 
//   console.log("Links =  " + document.links.length);

   
   const wrds = new RegExp("contact|team|staff", "gi");

   var flag = 0;
 
    
    var table = document.createElement('table');


    table.border = '2';
	//table.style.padding = '15px';
	table.style.borderWidth = "2px";
    table.style.borderColor = "#FFFFF";
    table.style.borderStyle = "solid";
    table.style.borderCollapse = "collapse";    
    table.style.borderspacing = "10px";

    
    table.style.margin = '15px';

   

    header=  document.createElement('thead');
    var headingRow = document.createElement('tr');

    var headingCell1 = document.createElement('td');
    
    headingCell1.style.borderWidth = "2px";
    headingCell1.style.borderColor = "#FFFFF";
    headingCell1.style.borderStyle = "solid";
    headingCell1.style.borderCollapse = "collapse";

    headingCell1.style.fontFamily = "Verdana,Lucida Console,sans-serif";
    headingCell1.style.fontSize = "25px";
    headingCell1.style.fontWeight = "bold";    
	
    headingCell1.style.color = "Black";

    headingCell1.style.paddingLeft = '15px';
    headingCell1.style.paddingRight = '10px';
    headingCell1.style.paddingTop = '10px';
    headingCell1.style.paddingBottom = '10px';
    
    var headingText1 = document.createTextNode('Text');
    headingCell1.appendChild(headingText1);
    headingRow.appendChild(headingCell1);
    
    var headingCell2 = document.createElement('td');
    
    headingCell2.style.borderWidth = "2px";
    headingCell2.style.borderColor = "#FFFFF";
    headingCell2.style.borderStyle = "solid";
    headingCell2.style.borderCollapse = "collapse";

    headingCell2.style.fontFamily = "Verdana,Lucida Console,sans-serif";
    headingCell2.style.fontSize = "25px";
    headingCell2.style.fontWeight = "bold";    
    
    headingCell2.style.color = "Black";


    headingCell2.style.paddingLeft = '15px';
    headingCell2.style.paddingRight = '10px';
    headingCell2.style.paddingTop = '10px';
    headingCell2.style.paddingBottom = '10px';
    
    var headingText2 = document.createTextNode('URL');
    headingCell2.appendChild(headingText2);
    headingRow.appendChild(headingCell2);

    header.appendChild(headingRow);
    
    table.appendChild(header);




    for (i = 0; i < links.length; i++) 
    {		

        if (flag == 0)
	   {
        for (var key of Object.keys(TitleLinks))
	   {
		var linkElement = document.createElement("a");
		var linkElement2 = document.createElement("a");

	  	//var lineBreak = document.createElement("br");

        	linkElement.setAttribute("href", TitleLinks[key]);
		
        	linkElement.setAttribute("title", TitleLinks[key]);

           linkElement.setAttribute("target", "_blank");
	
	
		linkElement2.setAttribute("href", TitleLinks[key]);
		
        	linkElement2.setAttribute("title", TitleLinks[key]);

           linkElement2.setAttribute("target", "_blank");


        
           var tr = document.createElement('tr');   

    		var td1 = document.createElement('td');
    		var td2 = document.createElement('td');
  
    		td1.style.paddingLeft = '15px';
    		td1.style.paddingRight = '10px';
    		td1.style.paddingTop = '10px';
    		td1.style.paddingBottom = '10px';
			

		td1.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td1.style.fontSize = "18px";
           
		td1.style.color = "Black";


    		td2.style.paddingLeft = '15px';
    		td2.style.paddingRight = '10px';
    		td2.style.paddingTop = '10px';
    		td2.style.paddingBottom = '10px';

		
		td1.style.borderWidth = "2px";
    		td1.style.borderColor = "#FFFFF";
    		td1.style.borderStyle = "solid";
    		td1.style.borderCollapse = "collapse";

		
		td2.style.borderWidth = "2px";
    		td2.style.borderColor = "#FFFFF";
    		td2.style.borderStyle = "solid";
    		td2.style.borderCollapse = "collapse";

		td2.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td2.style.fontSize = "18px";
		
		td2.style.color = "Black";


		if (TitleLinks[key])
           {
		if (key.match(wrds) || TitleLinks[key].match(wrds))
  		 {
			td1.style.color = "purple";
      		td1.style.backgroundColor = "yellow";

			td2.style.color = "purple";
      		td2.style.backgroundColor = "yellow";
  		 }
		}


		var text1 = document.createTextNode(key);
    		
		var text2 = document.createTextNode(TitleLinks[key]);

		
		linkElement.appendChild(text1);

		td1.appendChild(linkElement);


		linkElement2.appendChild(text2);

    		td2.appendChild(linkElement2);


    		tr.appendChild(td1);
    		tr.appendChild(td2);

		table.appendChild(tr);

		
		document.body.appendChild(table);


				
	   	//document.body.appendChild(linkElement);
	   	//document.body.appendChild(lineBreak);

    	   }
	   flag = 1;
	
	   document.body.appendChild(document.createElement("br"));
//document.body.appendChild(document.createElement("br"));

	   }

		
        if (links[i])
        {

        var linkElement = document.createElement("a");
        var linkElement2 = document.createElement("a");

	   // var lineBreak = document.createElement("br");


        linkElement.setAttribute("href", links[i]);

        linkElement.setAttribute("target", "_blank");


	   linkElement2.setAttribute("href", links[i]);

         linkElement2.setAttribute("target", "_blank");



        //  linkElement.appendChild(document.createTextNode(links[i]));

	
        
           var tr = document.createElement('tr');   

    		var td1 = document.createElement('td');
    		var td2 = document.createElement('td');
  
    		td1.style.paddingLeft = '15px';
    		td1.style.paddingRight = '10px';
    		td1.style.paddingTop = '10px';
    		td1.style.paddingBottom = '10px';

td1.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td1.style.fontSize = "18px";

    		td2.style.paddingLeft = '15px';
    		td2.style.paddingRight = '10px';
    		td2.style.paddingTop = '10px';
    		td2.style.paddingBottom = '10px';

		
		td1.style.borderWidth = "2px";
    		td1.style.borderColor = "#FFFFF";
    		td1.style.borderStyle = "solid";
    		td1.style.borderCollapse = "collapse";

		
		td2.style.borderWidth = "2px";
    		td2.style.borderColor = "#FFFFF";
    		td2.style.borderStyle = "solid";
    		td2.style.borderCollapse = "collapse";

		td2.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td2.style.fontSize = "18px";
		
		
		if (links[i])
           {
		if (links[i].match(wrds))
  		 {
			td1.style.color = "purple";
      		td1.style.backgroundColor = "yellow";

			td2.style.color = "purple";
      		td2.style.backgroundColor = "yellow";
  		 }
		}


		var text1 = document.createTextNode("No Title");
    		
		var text2 = document.createTextNode(links[i]);

		
		linkElement.appendChild(text1);

		td1.appendChild(linkElement);


		linkElement2.appendChild(text2);

    		td2.appendChild(linkElement2);


    		tr.appendChild(td1);
    		tr.appendChild(td2);

		table.appendChild(tr);

		
		document.body.appendChild(table);

         }
				
	   //document.body.appendChild(linkElement);
	   //document.body.appendChild(lineBreak);
    }



 // Page Title
		



		var linkElement = document.createElement("a");

		//linkElement.setAttribute("href", "javascript:UpdatePageTitle()");

           //linkElement.setAttribute("onclick", "UpdatePageTitle()");

		//linkElement.setAttribute("text", "Page Title");

		
		linkElement.setAttribute("href", "javascript:alert(document.title.trim());");

          //linkElement.setAttribute("href", "UpdatePageTitle");



   		var tr = document.createElement('tr');   

    		var td1 = document.createElement('td');
    		var td2 = document.createElement('td');
  
    		td1.style.paddingLeft = '15px';
    		td1.style.paddingRight = '10px';
    		td1.style.paddingTop = '10px';
    		td1.style.paddingBottom = '10px';

td1.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td1.style.fontSize = "18px";

    		td2.style.paddingLeft = '15px';
    		td2.style.paddingRight = '10px';
    		td2.style.paddingTop = '10px';
    		td2.style.paddingBottom = '10px';

		
		td1.style.borderWidth = "2px";
    		td1.style.borderColor = "#FFFFF";
    		td1.style.borderStyle = "solid";
    		td1.style.borderCollapse = "collapse";

		
		td2.style.borderWidth = "2px";
    		td2.style.borderColor = "#FFFFF";
    		td2.style.borderStyle = "solid";
    		td2.style.borderCollapse = "collapse";

		td2.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td2.style.fontSize = "18px";


		var text1 = document.createTextNode("Page Title");	


		var text2 = document.createTextNode(document.title.trim());

	
			
	      td2.setAttribute("id", "idpagetitle");

 
		linkElement.appendChild(text1);

		td1.appendChild(linkElement);


    		td2.appendChild(text2);


   tr.appendChild(td1);

   tr.appendChild(td2);

   table.appendChild(tr);

	
   document.body.appendChild(table);


 




   // Page URL
		

		var linkElement = document.createElement("a");
		var linkElement2 = document.createElement("a");
        
           var pageurl = window.location.href;		



   		var tr = document.createElement('tr');   

    		var td1 = document.createElement('td');
    		var td2 = document.createElement('td');
  
    		td1.style.paddingLeft = '15px';
    		td1.style.paddingRight = '10px';
    		td1.style.paddingTop = '10px';
    		td1.style.paddingBottom = '10px';

td1.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td1.style.fontSize = "18px";

    		td2.style.paddingLeft = '15px';
    		td2.style.paddingRight = '10px';
    		td2.style.paddingTop = '10px';
    		td2.style.paddingBottom = '10px';

		
		td1.style.borderWidth = "2px";
    		td1.style.borderColor = "#FFFFF";
    		td1.style.borderStyle = "solid";
    		td1.style.borderCollapse = "collapse";

		
		td2.style.borderWidth = "2px";
    		td2.style.borderColor = "#FFFFF";
    		td2.style.borderStyle = "solid";
    		td2.style.borderCollapse = "collapse";

		td2.style.fontFamily = "Verdana,Lucida Console,sans-serif";
		td2.style.fontSize = "18px";


		var text1 = document.createTextNode("Page URL");

      
           var text2 = document.createTextNode(pageurl);
		
			
	      td2.setAttribute("id", "idpageurl");


 		 linkElement2.setAttribute("id", "pguid");



		//linkElement.setAttribute("href", "javascript:navigator.clipboard.writeText(pageurl);");

		
		//linkElement.setAttribute("href", "javascript:document.getElementById('idpageurl').Select();");
				
		
		linkElement.setAttribute("href", "javascript:alert(window.location.href);");



		linkElement2.setAttribute("href", pageurl);


		linkElement.appendChild(text1);

		td1.appendChild(linkElement);

		

			
		linkElement2.appendChild(text2);

    		td2.appendChild(linkElement2);
		
		


   tr.appendChild(td1);

   tr.appendChild(td2);

   table.appendChild(tr);

	
   document.body.appendChild(table);




   //scrollToBottom();   


   var top = document.getElementById("exlu").offsetTop; 
	
			//Getting Y of target element

   window.scrollTo(0, top);        

                //Go there directly or some transition


}

  browser.runtime.onMessage.addListener((message) => {
    if (message.command === "extractAll") {
						extractLinksMain("");
    } else if (message.command === "extractByFilter") 
    {
       var txt = "contact|committee|staff|team|board|about|employee|management|bestuur|bureau|medewerkers|over-ons|chi-siamo|chi_siamo|direttivo|vorstand|despre-noi|comitete|conducere|comite|nuestro-equipo|Kurullar|iletisim|conseil-administration|duzenlemekurulu|veranstaltungen|geschaeftsstelle|kapcsolat|ansatte|medarbeidere|kontakt|impressum|imprint|events|calendar|leadership|chair|equipe|contatti|organ|organization|crew|pdf|governance|council|epikoinonia|touch|ueber-uns|komitee|unternehmen|praesidium|ansprechpartner|om-oss|Styret|konferansekomit|tel:|o-nas";

						extractLinksMain(txt);
    }
  });
